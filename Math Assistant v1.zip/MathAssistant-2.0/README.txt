For fresh install execute the script: (Script Specific for Ubuntu systems only!)

install.sh


For Running the Math Assistant Tool execute the script:

MathAssistant.sh



Note:

To execute a shell script do the following:

1) Open the Terminal

2) Change directory (using cd commmand) to the MathAssistant folder containing the script files (install.sh and MathAssistant.sh)

3) Run the command:

	sh "shellscript"	or	 ./"shellscript"
	
	For example:
	
	sh install.sh		or	 ./install.sh
	


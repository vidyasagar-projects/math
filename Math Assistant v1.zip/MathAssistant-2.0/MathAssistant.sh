cd MA
python MathAssistant.py


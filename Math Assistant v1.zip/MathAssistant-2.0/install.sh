sudo apt-get update
sudo apt-get install python2.5 python-wxgtk2.8

